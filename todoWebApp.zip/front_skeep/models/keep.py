import dataclasses


@dataclasses.dataclass
class Keep:
    keep_id: int
    title: str
